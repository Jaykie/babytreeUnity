﻿using UnityEngine;
using System.Collections;

namespace HighlightingSystem
{
	public class HighlightingRenderer : HighlightingBase
	{

	}
}